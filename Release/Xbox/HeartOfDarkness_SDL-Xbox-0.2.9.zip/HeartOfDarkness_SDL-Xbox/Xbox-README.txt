Ported by MVG/Lantus

Drop the Data Files in this folder and run the XBE. 

Source Code is provided

I had to backport SDL2 code to SDL1.2 so there are some minor graphical issues

Otherwise game is fully playable/completable

If you liked this and want to see more OG Xbox ports - follow/like/Sub to me on YouTube

https://www.youtube.com/ModernVintageGamer

or consider supporting me on Patreon

https://www.patreon.com/ModernVintageGamer



